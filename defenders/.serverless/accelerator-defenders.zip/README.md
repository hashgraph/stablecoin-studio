# Accelerator Integration with OZ Defender

## Introduction
This module includes everything required to monitor your factory and stable coins using the Open Zeppelin Defenders platform.
For more information on OZ Defenders check their [official documentation](https://docs.openzeppelin.com/defender/).


## Prerequisites

## Deployment

## Post deployment


