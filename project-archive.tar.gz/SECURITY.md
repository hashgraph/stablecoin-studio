# Security Policy

## Reporting a Vulnerability

Please do not file a public ticket mentioning the vulnerability. To report a vulnerability, please send an email to <security@hashgraph.com>.
