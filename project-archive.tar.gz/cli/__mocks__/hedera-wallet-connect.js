// __mocks__/hedera-wallet-connect.js
module.exports = {};
