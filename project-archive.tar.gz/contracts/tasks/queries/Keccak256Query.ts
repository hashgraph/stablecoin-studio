export default class Keccak256Query {
    public readonly input: string

    public constructor(input: string) {
        this.input = input
    }
}
