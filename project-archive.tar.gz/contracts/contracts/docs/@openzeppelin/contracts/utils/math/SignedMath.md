# SignedMath







*Standard signed math utilities missing in the Solidity language.*



