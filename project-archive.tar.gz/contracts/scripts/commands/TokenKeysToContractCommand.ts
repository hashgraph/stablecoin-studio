import { BaseTokenKeysCommand } from '@scripts'

export default class TokenKeysToContractCommand extends BaseTokenKeysCommand {}
