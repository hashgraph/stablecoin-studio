import { TokenKeysToKeyCommand } from '@scripts'

export default class AllTokenKeysToKeyCommand extends TokenKeysToKeyCommand {}
