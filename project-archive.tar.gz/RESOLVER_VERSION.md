| Version | Contract name   | Address     | Network |
|---------| --------------  | ----------- | ------- |
| 2.1.6   | ResolverAddress | 0.0.6431794 | Testnet |
| 2.1.5   | ResolverAddress | 0.0.6349477 | Testnet |
| 2.0.0   | ResolverAddress | 0.0.6095328 | Testnet |
