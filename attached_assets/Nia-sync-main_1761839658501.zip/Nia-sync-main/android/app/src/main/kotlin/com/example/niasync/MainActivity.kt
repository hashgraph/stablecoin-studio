package com.example.niasync

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
